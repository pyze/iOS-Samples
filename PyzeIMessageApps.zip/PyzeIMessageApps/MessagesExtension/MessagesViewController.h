//
//  MessagesViewController.h
//  MessagesExtension
//
//  Created by Ramachandra Naragund on 21/09/16.
//  Copyright © 2016 Ramachandra Naragund. All rights reserved.
//

#import <Messages/Messages.h>

@interface MessagesViewController : MSMessagesAppViewController

@end
